import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler

# Load Data
df = pd.read_csv('worldcities.csv')
X = df[['lat', 'lng']].sample(500)  # sample for simplicity
X_scaled = StandardScaler().fit_transform(X)

# DBSCAN
db = DBSCAN(eps=0.3, min_samples=5).fit(X_scaled)
plt.scatter(X['lat'], X['lng'], c=db.labels_, cmap='rainbow', s=10)
plt.xlabel('Latitude')
plt.ylabel('Longitude')
plt.title('City Clustering with DBSCAN')
plt.show()