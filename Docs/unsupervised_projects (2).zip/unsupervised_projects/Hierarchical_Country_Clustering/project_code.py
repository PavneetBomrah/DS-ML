import pandas as pd
from sklearn.preprocessing import StandardScaler
from scipy.cluster.hierarchy import dendrogram, linkage
import matplotlib.pyplot as plt

# Load Data
df = pd.read_csv("Country-data.csv")
X = StandardScaler().fit_transform(df.drop('country', axis=1))

# Hierarchical Clustering
linked = linkage(X, method='ward')
plt.figure(figsize=(10, 6))
dendrogram(linked, labels=df['country'].values, orientation='top', distance_sort='descending')
plt.title('Country Clustering Dendrogram')
plt.xlabel('Country')
plt.ylabel('Distance')
plt.show()